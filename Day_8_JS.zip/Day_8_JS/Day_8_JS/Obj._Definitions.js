

let Bike = {Company:"Splendor", Model:"i3s", Color:"Black", Cost:"80,000"};
document.write(Bike.Company + " " + Bike.Model + " " + Bike.Color + " " + Bike.Cost);

const BikeObj = {Company:"Splendor", Model:"i3s", Color:"Black", Cost:"80,000"};
document.write("<br/>"+ BikeObj.Company + " " + BikeObj.Model + " " + BikeObj.Color + " " + BikeObj.Cost);


